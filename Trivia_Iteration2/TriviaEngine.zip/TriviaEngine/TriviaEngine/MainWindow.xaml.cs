﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TriviaEngine;
using System.Collections;
using System.Data.SQLite;

namespace TriviaEngine
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        QuestionAndAnswer qa;
        Starmap starmap = new Starmap(4, 4);
        private Player player;

        public MainWindow()
        {
            starmap.initialize();
            player = new Player(starmap.getSpaceport(0, 0));
            InitializeComponent();
        }

        public void playerMove(Spaceport spaceport)
        {
          
            if(player.getCoordinates().Equals(spaceport.getCoordinates()))
               MessageBox.Show("You are already at this location");
            else
            ValidMove(spaceport);
       
         /*   else
            {
                TriviaWindow triviaWindow = new TriviaWindow();
                triviaWindow.Show();
                player.setCoordinates(spaceport.getCoordinates());
            }*/
        }

        public void ValidMove(Spaceport spaceport)
        {
            Coordinates destination = spaceport.getCoordinates();
            List<Trajectory> trajectories = player.getCurr().getTrajectories();
            bool valid = false;
            Trajectory traj = null;
            trajectories.ForEach(delegate(Trajectory curr)
                                 {
                                     if (curr.getCoordinates().Equals(destination) && curr.getLocked() != 2)
                                     {
                                         valid = true;
                                         traj = curr;
                                     }
                                 });
            if (valid == true)
            {
                if (traj.getLocked() == 0)
                {
                    Coordinates prev = player.getCoordinates();
                    player.setCoordinates(traj.getCoordinates());
                    player.setSpaceport(spaceport);
                    updateReturnTrajectoryOpen(prev, spaceport.getTrajectories());
                }
                else
                {
                    TriviaWindow triviaWindow = new TriviaWindow();
                    triviaWindow.Show();
                    Coordinates prev = player.getCoordinates();
                    player.setCoordinates(spaceport.getCoordinates());
                    player.setSpaceport(spaceport);
                    updateReturnTrajectoryOpen(prev, spaceport.getTrajectories());
                }
            }
        }

        public void updateReturnTrajectoryOpen(Coordinates coordinates, List<Trajectory> trajectories)
        {
            trajectories.ForEach(delegate(Trajectory curr)
            {
                if (curr.getCoordinates().Equals(coordinates))
                {
                   curr.setLocked(0);
                }
            });
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Spaceport spaceport = starmap.getSpaceport(0, 0);
            Button btn = (Button)sender;
            if (btn == PlanetButton1)
            {
                spaceport = starmap.getSpaceport(0, 0);
                playerMove(spaceport);
            }
            if (btn == PlanetButton2)
            {
                spaceport = starmap.getSpaceport(0, 1);
                playerMove(spaceport);

            }
            if (btn == PlanetButton3)
            {
                spaceport = starmap.getSpaceport(1, 0);
                playerMove(spaceport);
            }


        }
    }
}